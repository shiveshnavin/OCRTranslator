package nf.co.hoptec.ocr;

/**
 * Created by shivesh on 19/1/17.
 */

public class tmp
{

    public static String txt="Azerbaijan\taz\tMacedonian\tmk\n" +
            "Albanian\tsq\tMaori\tmi\n" +
            "Amharic\tam\tMarathi\tmr\n" +
            "English\ten\tMari\tmhr\n" +
            "Arabic\tar\tMongolian\tmn\n" +
            "Armenian\thy\tGerman\tde\n" +
            "Afrikaans\taf\tNepali\tne\n" +
            "Basque\teu\tNorwegian\tno\n" +
            "Bashkir\tba\tPunjabi\tpa\n" +
            "Belarusian\tbe\tPapiamento\tpap\n" +
            "Bengali\tbn\tPersian\tfa\n" +
            "Bulgarian\tbg\tPolish\tpl\n" +
            "Bosnian\tbs\tPortuguese\tpt\n" +
            "Welsh\tcy\tRomanian\tro\n" +
            "Hungarian\thu\tRussian\tru\n" +
            "Vietnamese\tvi\tCebuano\tceb\n" +
            "Haitian (Creole)\tht\tSerbian\tsr\n" +
            "Galician\tgl\tSinhala\tsi\n" +
            "Dutch\tnl\tSlovakian\tsk\n" +
            "Hill Mari\tmrj\tSlovenian\tsl\n" +
            "Greek\tel\tSwahili\tsw\n" +
            "Georgian\tka\tSundanese\tsu\n" +
            "Gujarati\tgu\tTajik\ttg\n" +
            "Danish\tda\tThai\tth\n" +
            "Hebrew\the\tTagalog\ttl\n" +
            "Yiddish\tyi\tTamil\tta\n" +
            "Indonesian\tid\tTatar\ttt\n" +
            "Irish\tga\tTelugu\tte\n" +
            "Italian\tit\tTurkish\ttr\n" +
            "Icelandic\tis\tUdmurt\tudm\n" +
            "Spanish\tes\tUzbek\tuz\n" +
            "Kazakh\tkk\tUkrainian\tuk\n" +
            "Kannada\tkn\tUrdu\tur\n" +
            "Catalan\tca\tFinnish\tfi\n" +
            "Kyrgyz\tky\tFrench\tfr\n" +
            "Chinese\tzh\tHindi\thi\n" +
            "Korean\tko\tCroatian\thr\n" +
            "Xhosa\txh\tCzech\tcs\n" +
            "Latin\tla\tSwedish\tsv\n" +
            "Latvian\tlv\tScottish\tgd\n" +
            "Lithuanian\tlt\tEstonian\tet\n" +
            "Malagasy\tmg\tEsperanto\teo\n" +
            "Malay\tms\tJavanese\tjv\n" +
            "Malayalam\tml\tJapanese\tja\n" +
            "Maltese\tmt\t\t\n" +
            "\n";



}
